﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRent
{
    public partial class Form1 : Form
    {
        public static int objInd = -1;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

            lstCar.Items.Clear();
            objList.VehichleList.Add(new Vehicle(txtMark.Text, txtModel.Text, txtYear.Text, txtRegNo.Text,Convert.ToInt32(numKilo.Value)));

            foreach (Vehicle v in objList.VehichleList)
            {
                lstCar.Items.Add(v.Mark + " " + v.Model + " - " + v.RegNo);
            }
            clear();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            btnsEnable(false, false);
        }

        private void lstCar_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstCar.SelectedIndex >=0 )
            {
                Cal newCal = new Cal();


                chkAdd.Checked = false;
                btnsEnable(false, true);
                objInd = lstCar.SelectedIndex;

                txtMark.Text = objList.VehichleList[objInd].Mark;
                txtModel.Text = objList.VehichleList[objInd].Model;
                txtYear.Text = objList.VehichleList[objInd].Year;
                txtRegNo.Text = objList.VehichleList[objInd].RegNo;
                numKilo.Value = Convert.ToInt32(objList.VehichleList[objInd].Kilo);

                txtEcoFule.Text = newCal.eCoFule(objInd).ToString("##.##");

                int numofService, nextserv;

                numofService = objList.VehichleList[objInd].newService.Count;
                
                txtServiceNum.Text = numofService.ToString();

                if (numofService > 0)
                {
                    nextserv = objList.VehichleList[objInd].newService[numofService-1].NextSerivice;
                    txtNextSerivce.Text = nextserv.ToString();
                }
            }
        }

        private void lstCar_DoubleClick(object sender, EventArgs e)
        {



        }

        private void btnJouney_Click(object sender, EventArgs e)
        {

            if (objInd >= 0)
            {
                frmJourney journeyAdd = new frmJourney();
                journeyAdd.ShowDialog();


            }


        }

        private void clear()
        {

            txtMark.Text = "";
            txtModel.Text = "";
            txtRegNo.Text = "";
            txtYear.Text = "";
            numKilo.Value = 0;
        }
        private void btnsEnable(bool ON, bool OFF)
        {
            btnAdd.Enabled = ON;
            btnJouney.Enabled = OFF;
            btnFillFule.Enabled = OFF;
            btnServices.Enabled = OFF;
            txtMark.Enabled = ON;
            txtModel.Enabled = ON;
            txtYear.Enabled = ON;
            txtRegNo.Enabled = ON;
            numKilo.Enabled = ON;

        }



        private void chkAdd_CheckedChanged(object sender, EventArgs e)
        {
            if (chkAdd.Checked == true)
            {
                btnsEnable(true, false);
                clear();
            }
            else
            {
                btnsEnable(false, false);
            }
        }

        private void btnFillFule_Click(object sender, EventArgs e)
        {
            if (objInd >= 0)
            {
                frmRefill Refillform = new frmRefill();

                Refillform.ShowDialog();


            }
        }

        private void btnServices_Click(object sender, EventArgs e)
        {

            if (objInd >= 0)
            {
                frmServices serviceAdd = new frmServices();
                serviceAdd.ShowDialog();


            }
        }

        private void btnPerDay_Click(object sender, EventArgs e)
        {

        }

        private void btnPerKm_Click(object sender, EventArgs e)
        {
            if (objInd >= 0)
            {
                frmPerKm RentToAdd = new frmPerKm();
                RentToAdd.ShowDialog();


            }
        }
    }
}
