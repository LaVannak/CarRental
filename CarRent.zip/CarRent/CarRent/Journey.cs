﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRent
{
    public class Journey
    {
        public string Distination { get; set; }
        public double Distance { get; set; } 
        public string JDate { get; set; }
        public string JType { get; set; }

        public Journey()
        {

        }
        
        public Journey(string distination, double distanace, string jdate, string jtype)
        {
            Distination = distination;
            Distance = distanace;
            JDate = jdate;
            JType = jtype;
        }

    }
}
