﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRent
{
    public partial class frmRefill : Form
    {
        public frmRefill()
        {
            InitializeComponent();
        }

        private void frmRefill_Load(object sender, EventArgs e)
        {
            lblVehicle.Text = objList.VehichleList[Form1.objInd].Mark + " " +
                  objList.VehichleList[Form1.objInd].Model + " " +
                  objList.VehichleList[Form1.objInd].Year + " - " +
                  objList.VehichleList[Form1.objInd].RegNo;
              numKiloat.Value = Convert.ToInt32(objList.VehichleList[Form1.objInd].Kilo);

              dtFill.Value = DateTime.Today;

            
        }

        private void btnFill_Click(object sender, EventArgs e)
        {
            objList.VehichleList[Form1.objInd].flueAdd.Add(new FuleAdd(Convert.ToDouble((numKiloat).Value), Convert.ToDouble(numFule.Value), dtFill.Value.ToShortDateString()));
            MessageBox.Show("Fule record has been added into Log-book");
            this.Hide();
        }



        private void numFule_ValueChanged(object sender, EventArgs e)
        {
            if (numFule.Value > 0 && numPrice.Value>0)
            {
                btnFill.Enabled = true;
            }
        }

        private void numPrice_ValueChanged(object sender, EventArgs e)
        {
            if (numFule.Value > 0 && numPrice.Value > 0)
            {
                btnFill.Enabled = true;
            }
        }
    }
}
