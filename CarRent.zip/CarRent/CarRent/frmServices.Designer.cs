﻿namespace CarRent
{
    partial class frmServices
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtServiceDate = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.numKiloat = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.numNextService = new System.Windows.Forms.NumericUpDown();
            this.btnLog = new System.Windows.Forms.Button();
            this.btlVehicle = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numKiloat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNextService)).BeginInit();
            this.SuspendLayout();
            // 
            // dtServiceDate
            // 
            this.dtServiceDate.Location = new System.Drawing.Point(29, 47);
            this.dtServiceDate.Name = "dtServiceDate";
            this.dtServiceDate.Size = new System.Drawing.Size(242, 20);
            this.dtServiceDate.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(28, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 18);
            this.label1.TabIndex = 1;
            this.label1.Text = "Killomaters";
            // 
            // numKiloat
            // 
            this.numKiloat.Enabled = false;
            this.numKiloat.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numKiloat.Location = new System.Drawing.Point(29, 97);
            this.numKiloat.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.numKiloat.Name = "numKiloat";
            this.numKiloat.Size = new System.Drawing.Size(108, 24);
            this.numKiloat.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label2.Location = new System.Drawing.Point(163, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 18);
            this.label2.TabIndex = 3;
            this.label2.Text = "Next Services";
            // 
            // numNextService
            // 
            this.numNextService.Enabled = false;
            this.numNextService.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numNextService.Location = new System.Drawing.Point(166, 97);
            this.numNextService.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.numNextService.Name = "numNextService";
            this.numNextService.Size = new System.Drawing.Size(105, 24);
            this.numNextService.TabIndex = 4;
            // 
            // btnLog
            // 
            this.btnLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLog.ForeColor = System.Drawing.Color.Maroon;
            this.btnLog.Location = new System.Drawing.Point(29, 136);
            this.btnLog.Name = "btnLog";
            this.btnLog.Size = new System.Drawing.Size(242, 27);
            this.btnLog.TabIndex = 5;
            this.btnLog.Text = "Log Service";
            this.btnLog.UseVisualStyleBackColor = true;
            this.btnLog.Click += new System.EventHandler(this.btnLog_Click);
            // 
            // btlVehicle
            // 
            this.btlVehicle.AutoSize = true;
            this.btlVehicle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btlVehicle.ForeColor = System.Drawing.Color.DarkGreen;
            this.btlVehicle.Location = new System.Drawing.Point(29, 13);
            this.btlVehicle.Name = "btlVehicle";
            this.btlVehicle.Size = new System.Drawing.Size(60, 24);
            this.btlVehicle.TabIndex = 6;
            this.btlVehicle.Text = "label3";
            // 
            // frmServices
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(298, 175);
            this.Controls.Add(this.btlVehicle);
            this.Controls.Add(this.btnLog);
            this.Controls.Add(this.numNextService);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.numKiloat);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtServiceDate);
            this.Name = "frmServices";
            this.Text = "Service Log";
            this.Load += new System.EventHandler(this.frmServices_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numKiloat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNextService)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtServiceDate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numKiloat;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown numNextService;
        private System.Windows.Forms.Button btnLog;
        private System.Windows.Forms.Label btlVehicle;
    }
}