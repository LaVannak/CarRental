﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRent
{
    public partial class frmServices : Form
    {
        public frmServices()
        {
            InitializeComponent();
        }

        private void frmServices_Load(object sender, EventArgs e)
        {
            btlVehicle.Text = objList.VehichleList[Form1.objInd].Mark + " " +
      objList.VehichleList[Form1.objInd].Model + " " +
      objList.VehichleList[Form1.objInd].Year + " - " +
      objList.VehichleList[Form1.objInd].RegNo;
            numKiloat.Value = Convert.ToInt32(objList.VehichleList[Form1.objInd].Kilo);
            numNextService.Value = Convert.ToInt32(objList.VehichleList[Form1.objInd].Kilo) + 100;

            dtServiceDate.Value = DateTime.Today;
        }

        private void btnLog_Click(object sender, EventArgs e)
        {
            objList.VehichleList[Form1.objInd].newService.Add(new Services(dtServiceDate.Value.ToShortDateString(),
                Convert.ToInt32(numKiloat.Value), Convert.ToInt32(numNextService.Value)));
                
            MessageBox.Show("Service record has been added into Log-book");
            this.Hide();
        }
    }
}
