﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRent
{
    public class Cal
    {
        public Cal()
        {
        }
        public double VRevenue(int objindex, int fee)
        {
            double objRevenue = objList.VehichleList[objindex].Revenue;
            objRevenue = objRevenue + fee;
            return objRevenue;
        }


        // Method count Kilo of Travel:

        public double TravelKilo(int objindex, int KiloInput)
        {
            double objKilo = objList.VehichleList[objindex].Kilo;

            objKilo = objKilo + KiloInput;
            return objKilo;
        }

        // Metho to calculate Ecomonimic Fule Consumsion

        /*
         * 0            200Km                   400Km                500Km  --> Total Kilo = 1100Km 
         * |A------------B|-----------------------C|--------------------D|
         * 50L   Beach   20L    Free Way         30L    Mountants      60L  --> Total Fule = 110L
         * 
         * flueEco (D) = (D-C)/20L???
         * or                                      Doouble Check with lecture
         * flueEo = Total Kilo/Total Fule ????
         */
        public double eCoFule(int objindex)
        {
            
            double KiloPerLetter= 0;
            int num = objList.VehichleList[objindex].flueAdd.Count;

            if (objList.VehichleList[objindex].flueAdd.Count >= 2)
            {
                KiloPerLetter = (objList.VehichleList[objindex].flueAdd[num - 1].atKilometer - objList.VehichleList[objindex].flueAdd[num - 2].atKilometer) /
                    objList.VehichleList[objindex].flueAdd[num - 1].Amount;
            }
                return KiloPerLetter;
        }


    }
}
