﻿namespace CarRent
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtMark = new System.Windows.Forms.TextBox();
            this.txtModel = new System.Windows.Forms.TextBox();
            this.txtYear = new System.Windows.Forms.TextBox();
            this.txtRegNo = new System.Windows.Forms.TextBox();
            this.numKilo = new System.Windows.Forms.NumericUpDown();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lstCar = new System.Windows.Forms.ListBox();
            this.btnJouney = new System.Windows.Forms.Button();
            this.btnFillFule = new System.Windows.Forms.Button();
            this.btnServices = new System.Windows.Forms.Button();
            this.chkAdd = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtServiceNum = new System.Windows.Forms.TextBox();
            this.txtEcoFule = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtNextSerivce = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnPerKm = new System.Windows.Forms.Button();
            this.btnPerDay = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.txtVRevenue = new System.Windows.Forms.TextBox();
            this.btnTotalRevenue = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numKilo)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(29, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mark";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label2.Location = new System.Drawing.Point(29, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Model";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label3.Location = new System.Drawing.Point(29, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Year";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label4.Location = new System.Drawing.Point(29, 177);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Registration No:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label5.Location = new System.Drawing.Point(29, 217);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Kilomaters:";
            // 
            // txtMark
            // 
            this.txtMark.Location = new System.Drawing.Point(145, 58);
            this.txtMark.Name = "txtMark";
            this.txtMark.Size = new System.Drawing.Size(100, 20);
            this.txtMark.TabIndex = 5;
            // 
            // txtModel
            // 
            this.txtModel.Location = new System.Drawing.Point(145, 98);
            this.txtModel.Name = "txtModel";
            this.txtModel.Size = new System.Drawing.Size(100, 20);
            this.txtModel.TabIndex = 6;
            // 
            // txtYear
            // 
            this.txtYear.Location = new System.Drawing.Point(145, 136);
            this.txtYear.Name = "txtYear";
            this.txtYear.Size = new System.Drawing.Size(100, 20);
            this.txtYear.TabIndex = 7;
            // 
            // txtRegNo
            // 
            this.txtRegNo.Location = new System.Drawing.Point(145, 169);
            this.txtRegNo.Name = "txtRegNo";
            this.txtRegNo.Size = new System.Drawing.Size(100, 20);
            this.txtRegNo.TabIndex = 8;
            // 
            // numKilo
            // 
            this.numKilo.Enabled = false;
            this.numKilo.Location = new System.Drawing.Point(145, 209);
            this.numKilo.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.numKilo.Name = "numKilo";
            this.numKilo.Size = new System.Drawing.Size(100, 20);
            this.numKilo.TabIndex = 9;
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(55, 288);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(190, 30);
            this.btnAdd.TabIndex = 10;
            this.btnAdd.Text = "Add New Car";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lstCar
            // 
            this.lstCar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstCar.FormattingEnabled = true;
            this.lstCar.ItemHeight = 16;
            this.lstCar.Location = new System.Drawing.Point(283, 58);
            this.lstCar.Name = "lstCar";
            this.lstCar.Size = new System.Drawing.Size(334, 260);
            this.lstCar.TabIndex = 11;
            this.lstCar.SelectedIndexChanged += new System.EventHandler(this.lstCar_SelectedIndexChanged);
            this.lstCar.DoubleClick += new System.EventHandler(this.lstCar_DoubleClick);
            // 
            // btnJouney
            // 
            this.btnJouney.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJouney.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnJouney.Location = new System.Drawing.Point(633, 98);
            this.btnJouney.Name = "btnJouney";
            this.btnJouney.Size = new System.Drawing.Size(138, 29);
            this.btnJouney.TabIndex = 12;
            this.btnJouney.Text = "Add Journey";
            this.btnJouney.UseVisualStyleBackColor = true;
            this.btnJouney.Click += new System.EventHandler(this.btnJouney_Click);
            // 
            // btnFillFule
            // 
            this.btnFillFule.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFillFule.ForeColor = System.Drawing.Color.Teal;
            this.btnFillFule.Location = new System.Drawing.Point(633, 58);
            this.btnFillFule.Name = "btnFillFule";
            this.btnFillFule.Size = new System.Drawing.Size(138, 29);
            this.btnFillFule.TabIndex = 13;
            this.btnFillFule.Text = "Fill Fuel";
            this.btnFillFule.UseVisualStyleBackColor = true;
            this.btnFillFule.Click += new System.EventHandler(this.btnFillFule_Click);
            // 
            // btnServices
            // 
            this.btnServices.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnServices.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnServices.Location = new System.Drawing.Point(633, 136);
            this.btnServices.Name = "btnServices";
            this.btnServices.Size = new System.Drawing.Size(138, 29);
            this.btnServices.TabIndex = 14;
            this.btnServices.Text = "Service Log";
            this.btnServices.UseVisualStyleBackColor = true;
            this.btnServices.Click += new System.EventHandler(this.btnServices_Click);
            // 
            // chkAdd
            // 
            this.chkAdd.AutoSize = true;
            this.chkAdd.Location = new System.Drawing.Point(34, 297);
            this.chkAdd.Name = "chkAdd";
            this.chkAdd.Size = new System.Drawing.Size(15, 14);
            this.chkAdd.TabIndex = 15;
            this.chkAdd.UseVisualStyleBackColor = true;
            this.chkAdd.CheckedChanged += new System.EventHandler(this.chkAdd_CheckedChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(30, 342);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(151, 20);
            this.label6.TabIndex = 16;
            this.label6.Text = "Number of Services:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(251, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(283, 25);
            this.label7.TabIndex = 17;
            this.label7.Text = "Vehicle Information Board";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(524, 342);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(118, 20);
            this.label8.TabIndex = 18;
            this.label8.Text = "Ecomonic Fuel:";
            // 
            // txtServiceNum
            // 
            this.txtServiceNum.Enabled = false;
            this.txtServiceNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtServiceNum.ForeColor = System.Drawing.Color.Purple;
            this.txtServiceNum.Location = new System.Drawing.Point(188, 341);
            this.txtServiceNum.Name = "txtServiceNum";
            this.txtServiceNum.Size = new System.Drawing.Size(57, 26);
            this.txtServiceNum.TabIndex = 19;
            // 
            // txtEcoFule
            // 
            this.txtEcoFule.Enabled = false;
            this.txtEcoFule.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEcoFule.ForeColor = System.Drawing.Color.Purple;
            this.txtEcoFule.Location = new System.Drawing.Point(648, 342);
            this.txtEcoFule.Name = "txtEcoFule";
            this.txtEcoFule.Size = new System.Drawing.Size(54, 26);
            this.txtEcoFule.TabIndex = 20;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(292, 342);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(101, 20);
            this.label9.TabIndex = 21;
            this.label9.Text = "Next Service:";
            // 
            // txtNextSerivce
            // 
            this.txtNextSerivce.Enabled = false;
            this.txtNextSerivce.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNextSerivce.ForeColor = System.Drawing.Color.Purple;
            this.txtNextSerivce.Location = new System.Drawing.Point(400, 342);
            this.txtNextSerivce.Name = "txtNextSerivce";
            this.txtNextSerivce.Size = new System.Drawing.Size(96, 26);
            this.txtNextSerivce.TabIndex = 22;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(702, 345);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(45, 20);
            this.label10.TabIndex = 23;
            this.label10.Text = "KM/L";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnPerKm);
            this.groupBox1.Controls.Add(this.btnPerDay);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.groupBox1.Location = new System.Drawing.Point(633, 169);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(138, 142);
            this.groupBox1.TabIndex = 24;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Rent Options";
            // 
            // btnPerKm
            // 
            this.btnPerKm.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPerKm.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnPerKm.Location = new System.Drawing.Point(7, 79);
            this.btnPerKm.Name = "btnPerKm";
            this.btnPerKm.Size = new System.Drawing.Size(125, 39);
            this.btnPerKm.TabIndex = 1;
            this.btnPerKm.Text = "Per KM";
            this.btnPerKm.UseVisualStyleBackColor = true;
            this.btnPerKm.Click += new System.EventHandler(this.btnPerKm_Click);
            // 
            // btnPerDay
            // 
            this.btnPerDay.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPerDay.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnPerDay.Location = new System.Drawing.Point(7, 24);
            this.btnPerDay.Name = "btnPerDay";
            this.btnPerDay.Size = new System.Drawing.Size(125, 36);
            this.btnPerDay.TabIndex = 0;
            this.btnPerDay.Text = "Per Day";
            this.btnPerDay.UseVisualStyleBackColor = true;
            this.btnPerDay.Click += new System.EventHandler(this.btnPerDay_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(517, 376);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(129, 20);
            this.label11.TabIndex = 25;
            this.label11.Text = "Vehicle Revenue";
            // 
            // txtVRevenue
            // 
            this.txtVRevenue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVRevenue.Location = new System.Drawing.Point(647, 375);
            this.txtVRevenue.Name = "txtVRevenue";
            this.txtVRevenue.Size = new System.Drawing.Size(100, 26);
            this.txtVRevenue.TabIndex = 26;
            // 
            // btnTotalRevenue
            // 
            this.btnTotalRevenue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTotalRevenue.Location = new System.Drawing.Point(32, 375);
            this.btnTotalRevenue.Name = "btnTotalRevenue";
            this.btnTotalRevenue.Size = new System.Drawing.Size(213, 26);
            this.btnTotalRevenue.TabIndex = 27;
            this.btnTotalRevenue.Text = "Total Revenue";
            this.btnTotalRevenue.UseVisualStyleBackColor = true;
            this.btnTotalRevenue.Click += new System.EventHandler(this.btnTotalRevenue_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(802, 412);
            this.Controls.Add(this.btnTotalRevenue);
            this.Controls.Add(this.txtVRevenue);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtNextSerivce);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtEcoFule);
            this.Controls.Add(this.txtServiceNum);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.chkAdd);
            this.Controls.Add(this.btnServices);
            this.Controls.Add(this.btnFillFule);
            this.Controls.Add(this.btnJouney);
            this.Controls.Add(this.lstCar);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.numKilo);
            this.Controls.Add(this.txtRegNo);
            this.Controls.Add(this.txtYear);
            this.Controls.Add(this.txtModel);
            this.Controls.Add(this.txtMark);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numKilo)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtMark;
        private System.Windows.Forms.TextBox txtModel;
        private System.Windows.Forms.TextBox txtYear;
        private System.Windows.Forms.TextBox txtRegNo;
        private System.Windows.Forms.NumericUpDown numKilo;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.ListBox lstCar;
        private System.Windows.Forms.Button btnJouney;
        private System.Windows.Forms.Button btnFillFule;
        private System.Windows.Forms.Button btnServices;
        private System.Windows.Forms.CheckBox chkAdd;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtServiceNum;
        private System.Windows.Forms.TextBox txtEcoFule;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtNextSerivce;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnPerKm;
        private System.Windows.Forms.Button btnPerDay;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtVRevenue;
        private System.Windows.Forms.Button btnTotalRevenue;
    }
}

