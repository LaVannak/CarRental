﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRent
{
    public class FuleAdd
    {
        public double atKilometer { get; set; }
        public double Amount { get; set; }
        public string RefillDate { get; set; }

        public FuleAdd() { }

        public FuleAdd(double atkilo, double amount, string refilldate)
        {
            atKilometer = atkilo;
            Amount = amount;
            RefillDate = refilldate;
        }
    }
}
