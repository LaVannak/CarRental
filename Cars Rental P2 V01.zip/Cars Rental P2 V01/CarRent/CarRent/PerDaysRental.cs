﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRent
{
    public class PerDaysRental
    {
        public PerDaysRental() { }

        public string StarDate { get; set; }
        public int NumOfDays { get; set; }
        public string RentTo { get; set; }
        public double RentalFee { get; set; }

        public PerDaysRental(string rentto, string startdate, int numofdays, double rentalfee)
        {
            RentTo = rentto;
            StarDate = startdate;
            NumOfDays = numofdays;
            RentalFee = rentalfee;
        }

    }
}
