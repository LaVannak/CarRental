﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CarRent 
{
    // Inheritate from Journey Class
    public class PerKmRental : Journey
    {
        String RentTo { get; set; }
        double RentalFee { get; set; }

        public PerKmRental() { }

        public PerKmRental(string rentto, double rentalfee, string distination, double distance, string jdate, string jtype)
        {
            RentTo = rentto;
            RentalFee = rentalfee;
            Distination = distination;
            Distance = distance;
            JDate = jdate;
            JType = jtype;
        }

    }
}
