﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRent
{
    public class Services
    {
        public string ServiceDaate { get; set; }
        public int ServiceAtKilo { get; set; }
        public int NextSerivice { get; set; }

        public Services() { }

        public Services(string servicedate, int serviceatkilo, int nextservice)
        {
            ServiceDaate = ServiceDaate;
            ServiceAtKilo = serviceatkilo;
            NextSerivice = nextservice;
    }
    }
}
