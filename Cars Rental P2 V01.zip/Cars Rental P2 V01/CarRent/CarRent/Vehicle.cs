﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRent
{
    public class Vehicle
    {
        public string Mark { get; set; }
        public string Model { get; set; }
        public string Year { get; set; }
        public string RegNo { get; set; }

        public double Kilo { get; set; }
        public double Revenue { get; set; }

        public  List<Journey> newJourney = new List<Journey>();
        public  List<FuleAdd> flueAdd = new List<FuleAdd>();
        public List<Services> newService = new List<Services>();
        public List<PerKmRental> newPerKmRental = new List<PerKmRental>();
        public List<PerDaysRental> newPerDaysRental = new List<PerDaysRental>();

        public Vehicle()
        {
        }

        public Vehicle(string mark, string model, string year, string regno, int kilo, double revenue)
        {
            Mark = mark;
            Model = model;
            Year = year;
            RegNo = regno;
            Kilo = kilo;
            Revenue = revenue;
        }


    }
}
