﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRent
{
    public partial class frmJourney : Form
    {
        public frmJourney()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            // Add Jouney info to list of Jouney of Vehicle
            objList.VehichleList[Form1.objInd].newJourney.Add(new Journey(txtDistination.Text, 
                Convert.ToInt32(numDistance.Value),dtJdate.Value.ToShortDateString(), cmbJtype.Text));

            MessageBox.Show("Jouney to "+ txtDistination.Text + " has been recorded in Log-book");

            // Add Kilo Travel to Kilometer of vehicle
            Cal NewCal = new Cal();

            objList.VehichleList[Form1.objInd].Kilo= NewCal.TravelKilo(Form1.objInd, Convert.ToInt32(numDistance.Value));


            this.Hide();
               
        }

        private void frmJourney_Load(object sender, EventArgs e)
        {
            // Populate Vehile Info to a display lebel

            lblDisplay.Text = objList.VehichleList[Form1.objInd].Mark + " " + 
                objList.VehichleList[Form1.objInd].Model +" "+
                objList.VehichleList[Form1.objInd].Year+ " - " +
                objList.VehichleList[Form1.objInd].RegNo;

            btnSubmit.Enabled = false;
        }

        private void txtDistination_TextChanged(object sender, EventArgs e)
        {
            if (txtDistination.Text !="" && numDistance.Value >0 && cmbJtype.Text !="")
            {
                btnSubmit.Enabled = true;
            }
        }

        private void numDistance_ValueChanged(object sender, EventArgs e)
        {
            if (txtDistination.Text != "" && numDistance.Value > 0 && cmbJtype.Text != "")
            {
                btnSubmit.Enabled = true;
            }
        }

        private void cmbJtype_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (txtDistination.Text != "" && numDistance.Value > 0 && cmbJtype.Text != "")
            {
                btnSubmit.Enabled = true;
            }
        }
    }
}
