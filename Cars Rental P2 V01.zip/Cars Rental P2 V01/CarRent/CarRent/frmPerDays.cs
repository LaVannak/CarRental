﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRent
{
    public partial class frmPerDays : Form
    {
        public frmPerDays()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void frmPerDays_Load(object sender, EventArgs e)
        {
            // Add Jouney info to list of Jouney of Vehicle

            lblDisplay.Text = objList.VehichleList[Form1.objInd].Mark + " " +
             objList.VehichleList[Form1.objInd].Model + " " +
             objList.VehichleList[Form1.objInd].Year + " - " +
             objList.VehichleList[Form1.objInd].RegNo;

            btnSubmite.Enabled = false;
        }

        private void lblDisplay_Click(object sender, EventArgs e)
        {

        }

        private void dtpStart_ValueChanged(object sender, EventArgs e)
        {


            
        }

        private void NumOfDays_ValueChanged(object sender, EventArgs e)
        {

            txtRentalFee.Text = (NumOfDays.Value * 100).ToString();
            if (txtRentTo.Text != "" && NumOfDays.Value > 0)
            {
                btnSubmite.Enabled = true;
            }
        }

        private void txtRentTo_TextChanged(object sender, EventArgs e)
        {
            if(txtRentTo.Text !="" && NumOfDays.Value >0)
            {
                btnSubmite.Enabled = true;
            }
        }

        private void btnSubmite_Click(object sender, EventArgs e)
        {
            // Add Rent Per Day info to list of Rent Per Day of Vehicle

            objList.VehichleList[Form1.objInd].newPerDaysRental.Add(new PerDaysRental(txtRentTo.Text, 
                dtpStart.Value.ToShortDateString(), Convert.ToInt32(NumOfDays.Value), 
                Convert.ToDouble(txtRentalFee.Text)));

            MessageBox.Show("Rental records of " + lblDisplay.Text + " has been recorded in Log-book");

            // Add  Revenue to Revenue variable of vehicle
            Cal NewCal = new Cal();

            objList.VehichleList[Form1.objInd].Revenue = NewCal.VRevenue(Form1.objInd, Convert.ToInt32(txtRentalFee.Text));

        }
    }
}
