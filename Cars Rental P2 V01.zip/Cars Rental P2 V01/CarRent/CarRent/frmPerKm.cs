﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRent
{
    public partial class frmPerKm: Form
    {
        public frmPerKm()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            objList.VehichleList[Form1.objInd].newPerKmRental.Add(new PerKmRental(txtRentTo.Text, Convert.ToDouble(txtRentFee.Text), txtDistination.Text, 
                Convert.ToInt32(numDistance.Value),dtJdate.Value.ToShortDateString(), cmbJtype.Text));

            MessageBox.Show("Rental records of "+ lblDisplay.Text + " has been recorded in Log-book");

            Cal NewCal = new Cal();

            objList.VehichleList[Form1.objInd].Kilo= NewCal.TravelKilo(Form1.objInd, Convert.ToInt32(numDistance.Value));
            objList.VehichleList[Form1.objInd].Revenue = NewCal.VRevenue(Form1.objInd, Convert.ToInt32(txtRentFee.Text));


            this.Hide();
               
        }

        private void frmJourney_Load(object sender, EventArgs e)
        {
            lblDisplay.Text = objList.VehichleList[Form1.objInd].Mark + " " + 
                objList.VehichleList[Form1.objInd].Model +" "+
                objList.VehichleList[Form1.objInd].Year+ " - " +
                objList.VehichleList[Form1.objInd].RegNo;

            btnSubmit.Enabled = false;
        }

        private void txtDistination_TextChanged(object sender, EventArgs e)
        {
            if (txtDistination.Text !="" && numDistance.Value >0 && cmbJtype.Text !="")
            {
                btnSubmit.Enabled = true;
                txtRentFee.Text = numDistance.Value.ToString();
            }
        }

        private void numDistance_ValueChanged(object sender, EventArgs e)
        {
            if (txtDistination.Text != "" && numDistance.Value > 0 && cmbJtype.Text != "")
            {
                btnSubmit.Enabled = true;
                txtRentFee.Text = numDistance.Value.ToString();
            }
        }

        private void cmbJtype_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (txtDistination.Text != "" && numDistance.Value > 0 && cmbJtype.Text != "")
            {
                btnSubmit.Enabled = true;
                txtRentFee.Text = numDistance.Value.ToString();
            }
        }
    }
}
